package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"os"
	"strings"

	"forge/internal/agent"
	"forge/internal/config"
)

func main() {
	cfg, err := config.Load()
	if err != nil {
		fatal(err)
	}

	rootFlag := flag.String("root", cfg.RootDir, "repository root directory")
	modelFlag := flag.String("model", cfg.Model, "ollama model name")
	modeFlag := flag.String("mode", cfg.ApprovalMode, "approval mode: suggest|auto")
	verboseFlag := flag.Bool("verbose", false, "print extra detail")
	flag.Parse()

	args := flag.Args()
	if len(args) == 0 {
		printUsage()
		os.Exit(2)
	}

	cfg.RootDir = *rootFlag
	cfg.Model = *modelFlag
	cfg.ApprovalMode = *modeFlag
	cfg.Verbose = *verboseFlag

	cmd := strings.ToLower(args[0])
	prompt := strings.TrimSpace(strings.Join(args[1:], " "))

	runner, err := agent.NewRunner(cfg)
	if err != nil {
		fatal(err)
	}

	ctx := context.Background()

	switch cmd {
	case "ask":
		if prompt == "" {
			fatal(errors.New("ask requires a prompt"))
		}
		resp, err := runner.Ask(ctx, prompt)
		if err != nil {
			fatal(err)
		}
		fmt.Println(resp)
	case "plan":
		if prompt == "" {
			fatal(errors.New("plan requires a prompt"))
		}
		plan, err := runner.Plan(ctx, prompt)
		if err != nil {
			fatal(err)
		}
		fmt.Println(plan.Pretty())
	case "edit":
		if prompt == "" {
			fatal(errors.New("edit requires a prompt"))
		}
		result, err := runner.Edit(ctx, prompt)
		if err != nil {
			fatal(err)
		}
		fmt.Println(result.Pretty())
	case "test":
		result, err := runner.Test(ctx)
		if err != nil {
			fatal(err)
		}
		fmt.Println(result.Pretty())
	case "fix":
		result, err := runner.Fix(ctx)
		if err != nil {
			fatal(err)
		}
		fmt.Println(result.Pretty())
	case "repo-summary":
		summary, err := runner.RepoSummary(ctx)
		if err != nil {
			fatal(err)
		}
		fmt.Println(summary)
	default:
		printUsage()
		fatal(fmt.Errorf("unknown command: %s", cmd))
	}
}

func printUsage() {
	fmt.Println(`Forge - local Go coding agent for Ollama

Usage:
  forge [flags] ask "question"
  forge [flags] plan "change request"
  forge [flags] edit "change request"
  forge [flags] test
  forge [flags] fix
  forge [flags] repo-summary

Flags:`)
	flag.PrintDefaults()
}

func fatal(err error) {
	fmt.Fprintln(os.Stderr, "error:", err)
	os.Exit(1)
}
